function moveH(obj, itarget) {
	clearInterval(obj.timer);

	obj.timer = setInterval(function() {
		var ispeed = (itarget - obj.offsetHeight) / 8;

		ispeed = ispeed > 0 ? Math.ceil(ispeed) : Math.floor(ispeed);

		if(obj.offsetHeight == itarget) {
			clearInterval(obj.timer)

		}

		obj.style.height = obj.offsetHeight + ispeed + 'px';

	}, 30);
}

function move(obj, itarget, callfunction) {
	clearInterval(obj.timer);

	obj.timer = setInterval(function() {
		var ispeed = (itarget - obj.offsetLeft) / 8;

		ispeed = ispeed > 0 ? Math.ceil(ispeed) : Math.floor(ispeed);

		if(obj.offsetLeft == itarget) {
			clearInterval(obj.timer)
			callfunction && callfunction();
		}

		obj.style.left = obj.offsetLeft + ispeed + 'px';

	}, 30);
}