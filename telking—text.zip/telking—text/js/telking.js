window.onload = function() {
	var oUl = document.getElementById("navigation-bar-ul");
	var aLi = oUl.getElementsByTagName("li");
	var oBg = aLi[aLi.length - 1];
	/* 导航条滚动下条*/
	for(var i = 0; i < aLi.length - 1; i++) {
		aLi[i].onmouseover = function() {
			startMove(oBg, this.offsetLeft);
		}

	}

	var iSpeed = 0;
	var left = 0;

	function startMove(obj, iTarget) {

		clearInterval(obj.timer);
		obj.timer = setInterval(function() {
			iSpeed += (iTarget - obj.offsetLeft) / 8;
			iSpeed *= 0.6;

			left += iSpeed;
			if(Math.abs(iSpeed) < 1 && Math.abs(left - iTarget) < 1) {
				clearInterval(obj.timer);
				obj.style.left = iTarget + "px";
			} else {
				obj.style.left = left + "px";
			}
		}, 30);
	}

	/*轮播图效果*/
	var oDiv = document.querySelector('.carousel');
	var oUl = document.querySelector('.carousel-ul');
	var Allimgli = oUl.querySelectorAll('.carousel-ul-li');
	var imgli = document.querySelector('.carousel-ul-li');
	var oDivL = document.querySelector(".carousel-left");
	var oDivR = document.querySelector(".carousel-right");
	var Sub = document.querySelector('.selector');
	var imgWidth = imgli.offsetWidth;

	oDiv.addEventListener('mouseenter', function() {
		oDivL.style.display = 'block';
		oDivR.style.display = 'block';
		clearInterval(timer);
	});
	oDiv.addEventListener('mouseleave', function() {
		oDivL.style.display = 'none';
		oDivR.style.display = 'none';
		timer = setInterval(function() {
			oDivR.click()
		}, 2000)
	});

	for(var i = 0; i < oUl.children.length; i++) { //轮播图ul
		var li = document.createElement('li');
		li.setAttribute('index', i);
		Sub.appendChild(li);
		li.addEventListener('click', function() {
			for(var i = 0; i < Sub.children.length; i++) {
				Sub.children[i].style.backgroundColor = '#C3C5C8';
				moveH(Sub.children[i], 10);
			}
			this.style.backgroundColor = '#fff';
			moveH(this, 15);
			var index = this.getAttribute('index');
			var withValue = -index * imgWidth;
			move(oUl, withValue);
		})
	}
	Sub.children[0].style.backgroundColor = '#fff';
	moveH(Sub.children[0], 15);

	var cloneFirst = oUl.children[0].cloneNode('true');
	oUl.appendChild(cloneFirst);

	var num = 0;
	var circle = 0;
	oDivR.addEventListener('click', function() {

		if(num == oUl.children.length - 1) {
			num = 0;
			oUl.style.left = 0 + 'px';
		}
		num++;
		move(oUl, -num * imgWidth);
		circle++;
		if(circle == Sub.children.length) {
			circle = 0;
		}

		circleChange()
	})
	oDivL.addEventListener('click', function() {

		if(num == 0) {
			num = oUl.children.length - 1;
			oUl.style.left = -num * imgWidth + 'px';
		}
		num--;
		move(oUl, -num * imgWidth);
		circle--;
		if(circle < 0) {
			circle = Sub.children.length - 1;
		}

		circleChange()
	})

	var timer = setInterval(function() {
		oDivR.click()
	}, 3000)

	function circleChange() {
		for(var i = 0; i < Sub.children.length; i++) {
			Sub.children[i].style.backgroundColor = '#C3C5C8';
			moveH(Sub.children[i], 10)
		}
		Sub.children[circle].style.backgroundColor = '#fff';
		moveH(Sub.children[circle], 15)
	};
	
	
	// var xhr = new XMLHttpRequest();
	// xhr.open('GET','https://edu.telking.com/api/?type=month',false)
	// xhr.send();
	// xhr.onreadystatechange=function(){
	// 	if(xhr.readyState == 4){
	// 		xhr_data = JSON.parse(xhr.responseText);
	// 		var series = xhr_data.data.series;
	// 		var xAxis  = xhr_data.data.xAxis;
	// 		console.log(xAxis)
	// 	}
	// };
	

	// function dio(){
	// 	return new Promise((resolve,reject)=>{
	// 		var xhr = new XMLHttpRequest();
	// 		xhr.open('GET','https://edu.telking.com/api/?type=month',true)
	// 		xhr.send();
	// 		xhr.onreadystatechange=function(){
	// 			resolve(xhr);
	// 			// if(xhr.readyState == 4){
	// 			// 	xhr_data = JSON.parse(xhr.responseText);
	// 			// 	var series = xhr_data.data.series;
	// 			// 	var xAxis  = xhr_data.data.xAxis;
	// 			// 	console.log(xAxis)
	// 			// }
				
	// 		};
	// 	});
	// }
	// function test(){
	// 	dio().then(r=>{
	// 		console.log(r);
	// 	});
	// }
	// test();
	
	/*echarts*/
	(function() {
		var myChart = echarts.init(document.querySelector('.echars-curve-box'));
		var xhr = new XMLHttpRequest();
		xhr.open('GET','https://edu.telking.com/api/?type=month',true)
		xhr.send();
		xhr.onreadystatechange=function(){
			if(xhr.readyState == 4){
				xhr_data = JSON.parse(xhr.responseText);
				var series = xhr_data.data.series;
				var xAxis  = xhr_data.data.xAxis;
				console.log(xAxis)
				option = {

					color: ['#367DEE'],
					xAxis: {
						axisTick: {
							show: false,
						},
						axisLine: {
							show: false
						},
						type: 'category',
						boundaryGap: false,
						data:xAxis,
					},
					yAxis: {
						type: "value",
						show: 'false',
						axisTick: {
							show: false,
						},
						axisLine: {
							show: false
						},
						splitLine: {
							lineStyle: {
								type: 'dashed',
							},
						},
						splitNumber: 5,
						axisLabel: {
							formatter: '{value} 人',
						},
		
					},
		
					grid: {
						top: '-3%',
						left: '3%',
						right: '4%',
						bottom: '3%',
						containLabel: true
					},
					series: [{
						data:series,
						type: 'line',
						smooth: true,
						areaStyle: {
							opacity: '0.1'
						},
						label: {
							normal: {
								show: true,
								position: 'top'
							}
						}
					}]
					
				};
		
				myChart.setOption(option);
			}
		};

	})();

	(function() {
		var bing = echarts.init(document.querySelector('.echars-bing-box'));
		option = {
			tooltip: {
				trigger: 'item',
				formatter: '{a} <br/>{b} : {c} ({d}%)'
			},

			series: [{
				name: '访问来源',
				type: 'pie',
				radius: '65%',
				center: ['50%', '47%'],
				data: [{
						value: 335,
						name: 'Mon'
					},
					{
						value: 310,
						name: 'Tue'
					},
					{
						value: 234,
						name: 'Wed'
					},
					{
						value: 135,
						name: 'Thu'
					},
					{
						value: 1548,
						name: 'Fri'
					}
				],
				emphasis: {
					itemStyle: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					}
				}
			}]
		};

		bing.setOption(option);
	})();

	(function() {
		var zhu = echarts.init(document.querySelector('.echars-zhu-box'));
		var xhr = new XMLHttpRequest();
		xhr.open('GET','https://edu.telking.com/api/?type=week',true)
		xhr.send();
		xhr.onreadystatechange=function(){
			if(xhr.readyState == 4){
				xhr_data = JSON.parse(xhr.responseText);
				var series = xhr_data.data.series;
				var xAxis  = xhr_data.data.xAxis;
				console.log(xAxis)
				option = {
					color: ['#3398DB'],
					tooltip: {
						trigger: 'axis',
						axisPointer: {
							type: 'shadow'
						}
					},
		
					grid: {
						left: '3%',
						right: '4%',
						bottom: '3%',
						containLabel: true
					},
					xAxis: [{
						type: 'category',
						data: xAxis,
						axisTick: {
							alignWithLabel: true,
							show: false,
						},
						axisLine: {
							show: false
						}
					}],
					yAxis: [{
							name: '商品数',
							nameTextStyle: {
								align: 'center',
							},
							splitLine: {
								lineStyle: {
									type: 'dotted',
								},
							},
							type: 'value',
							splitNumber: 5,
							axisTick: {
								alignWithLabel: true,
								show: false,
							},
							axisLine: {
								show: false
							}
		
						},
		
					],
					series: [{
						name: '直接访问',
						type: 'bar',
						barWidth: '30%',
						data:series,
					}]
				};

				zhu.setOption(option);
			}	
		}		
	})();
}